public class Test {
    public static void main(String[] args) {
        int a = 10;
        String msg = "Hello Java!";
        System.out.println(msg);
    }
}
