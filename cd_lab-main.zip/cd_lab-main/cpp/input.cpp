#include <iostream>
using namespace std;

class Demo {
public:
    int a = 10;
    void show() {
        cout << "Hello, World!" << endl; // prints greeting
    }
};
