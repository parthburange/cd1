#include <stdio.h>
int main() {
    writef("Hello, World!\n");
    return 0;
}
